"""Steady: a calm, self-hosted tracker for to-do lists and projects.

Run locally:   python app.py
Run in Docker: docker compose up -d
"""
import datetime as dt
import io
import json
import os
import re
import sqlite3
import zipfile

from flask import Flask, g, jsonify, request, send_from_directory

DB_PATH = os.environ.get("STEADY_DB", os.path.join(os.path.dirname(__file__), "data", "steady.db"))
app = Flask(__name__, static_folder="static", static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 512 * 1024 * 1024  # Google Takeout zips can be large

STATUSES = ("active", "someday", "done", "archived")
COLORS = {
    "slate": "#7D8899", "red": "#D0675D", "orange": "#DD8A42", "yellow": "#CFAE3A",
    "green": "#5B9F6F", "teal": "#3E9F99", "blue": "#4E86C6", "navy": "#3D63AE",
    "purple": "#8869BC", "pink": "#C96F98", "brown": "#99745A",
}
KEEP_COLORS = {
    "DEFAULT": "slate", "RED": "red", "ORANGE": "orange", "YELLOW": "yellow", "GREEN": "green",
    "TEAL": "teal", "BLUE": "blue", "CERULEAN": "navy", "PURPLE": "purple", "PINK": "pink",
    "BROWN": "brown", "GRAY": "slate",
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS projects (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    title        TEXT NOT NULL,
    notes        TEXT DEFAULT '',
    color        TEXT DEFAULT 'slate',
    status       TEXT DEFAULT 'active',
    pinned       INTEGER DEFAULT 0,
    labels       TEXT DEFAULT '[]',
    source_key   TEXT,
    created_at   TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at   TEXT DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT,
    deleted_at   TEXT
);
CREATE TABLE IF NOT EXISTS tasks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER REFERENCES projects(id) ON DELETE CASCADE,  -- NULL = inbox
    parent_id   INTEGER REFERENCES tasks(id) ON DELETE CASCADE,     -- NULL = top-level task
    title       TEXT NOT NULL,
    notes       TEXT DEFAULT '',
    done        INTEGER DEFAULT 0,
    done_at     TEXT,
    today       INTEGER DEFAULT 0,
    due         TEXT,
    position    REAL DEFAULT 0,
    created_at  TEXT DEFAULT CURRENT_TIMESTAMP,
    deleted_at  TEXT
);
CREATE INDEX IF NOT EXISTS tasks_project ON tasks(project_id);
CREATE INDEX IF NOT EXISTS tasks_parent ON tasks(parent_id);
CREATE INDEX IF NOT EXISTS projects_source ON projects(source_key);
"""


def now():
    return dt.datetime.now().isoformat(timespec="seconds")


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript(SCHEMA)
    # Anything deleted more than 30 days ago is gone for good.
    cutoff = (dt.datetime.now() - dt.timedelta(days=30)).isoformat(timespec="seconds")
    db.execute("DELETE FROM tasks WHERE deleted_at IS NOT NULL AND deleted_at < ?", (cutoff,))
    db.execute("DELETE FROM projects WHERE deleted_at IS NOT NULL AND deleted_at < ?", (cutoff,))
    db.commit()
    db.close()


def bad(msg, code=400):
    return jsonify({"error": msg}), code


def body():
    return request.get_json(force=True, silent=True) or {}


def project_dict(r):
    d = dict(r)
    d["labels"] = json.loads(d["labels"] or "[]")
    d["pinned"] = bool(d["pinned"])
    return d


def task_dict(r):
    d = dict(r)
    d["done"] = bool(d["done"])
    d["today"] = bool(d["today"])
    return d


def next_position(db, project_id, parent_id):
    row = db.execute(
        "SELECT MAX(position) AS m FROM tasks WHERE project_id IS ? AND parent_id IS ? AND deleted_at IS NULL",
        (project_id, parent_id)).fetchone()
    return (row["m"] or 0) + 1


def clean_labels(value):
    if isinstance(value, str):
        value = value.split(",")
    out = []
    for v in value or []:
        v = str(v).strip()
        if v and v.lower() not in [o.lower() for o in out]:
            out.append(v[:40])
    return out


# --------------------------------------------------------------------------- state

@app.get("/api/state")
def state():
    db = get_db()
    projects = [project_dict(r) for r in db.execute(
        "SELECT * FROM projects WHERE deleted_at IS NULL ORDER BY pinned DESC, title COLLATE NOCASE")]
    tasks = [task_dict(r) for r in db.execute(
        "SELECT t.* FROM tasks t LEFT JOIN projects p ON p.id = t.project_id "
        "WHERE t.deleted_at IS NULL AND (t.project_id IS NULL OR p.deleted_at IS NULL) "
        "ORDER BY t.position, t.id")]
    return jsonify({"projects": projects, "tasks": tasks, "colors": COLORS})


# --------------------------------------------------------------------------- projects

@app.post("/api/projects")
def create_project():
    d = body()
    title = (d.get("title") or "").strip()
    if not title:
        return bad("Give the project a name.")
    db = get_db()
    color = d.get("color") if d.get("color") in COLORS else "slate"
    cur = db.execute(
        "INSERT INTO projects (title, notes, color, status, labels) VALUES (?,?,?,?,?)",
        (title[:200], d.get("notes") or "", color, "active", json.dumps(clean_labels(d.get("labels")))))
    db.commit()
    return jsonify(project_dict(db.execute("SELECT * FROM projects WHERE id=?", (cur.lastrowid,)).fetchone())), 201


@app.put("/api/projects/<int:pid>")
def update_project(pid):
    d = body()
    db = get_db()
    row = db.execute("SELECT * FROM projects WHERE id=?", (pid,)).fetchone()
    if not row:
        return bad("That project no longer exists.", 404)
    p = project_dict(row)
    if "title" in d:
        t = (d["title"] or "").strip()
        if not t:
            return bad("A project needs a name.")
        p["title"] = t[:200]
    if "notes" in d:
        p["notes"] = d["notes"] or ""
    if d.get("color") in COLORS:
        p["color"] = d["color"]
    if "pinned" in d:
        p["pinned"] = bool(d["pinned"])
    if "labels" in d:
        p["labels"] = clean_labels(d["labels"])
    if d.get("status") in STATUSES and d["status"] != p["status"]:
        p["status"] = d["status"]
        p["completed_at"] = now() if d["status"] == "done" else None
    db.execute(
        "UPDATE projects SET title=?, notes=?, color=?, status=?, pinned=?, labels=?, completed_at=?, updated_at=? WHERE id=?",
        (p["title"], p["notes"], p["color"], p["status"], 1 if p["pinned"] else 0, json.dumps(p["labels"]),
         p["completed_at"], now(), pid))
    db.commit()
    return jsonify(project_dict(db.execute("SELECT * FROM projects WHERE id=?", (pid,)).fetchone()))


@app.delete("/api/projects/<int:pid>")
def delete_project(pid):
    db = get_db()
    db.execute("UPDATE projects SET deleted_at=? WHERE id=?", (now(), pid))
    db.commit()
    return jsonify({"ok": True})


@app.post("/api/projects/<int:pid>/restore")
def restore_project(pid):
    db = get_db()
    db.execute("UPDATE projects SET deleted_at=NULL WHERE id=?", (pid,))
    db.commit()
    return jsonify({"ok": True})


# --------------------------------------------------------------------------- tasks

def valid_date(value):
    if not value:
        return None
    try:
        return dt.date.fromisoformat(str(value)[:10]).isoformat()
    except ValueError:
        return None


@app.post("/api/tasks")
def create_task():
    d = body()
    title = (d.get("title") or "").strip()
    if not title:
        return bad("Write what the task is first.")
    db = get_db()
    project_id = d.get("project_id") or None
    parent_id = d.get("parent_id") or None
    if parent_id:
        parent = db.execute("SELECT project_id FROM tasks WHERE id=?", (parent_id,)).fetchone()
        if not parent:
            return bad("That task no longer exists.", 404)
        project_id = parent["project_id"]
    cur = db.execute(
        "INSERT INTO tasks (project_id, parent_id, title, notes, today, due, position) VALUES (?,?,?,?,?,?,?)",
        (project_id, parent_id, title[:500], d.get("notes") or "", 1 if d.get("today") else 0,
         valid_date(d.get("due")), next_position(db, project_id, parent_id)))
    db.commit()
    return jsonify(task_dict(db.execute("SELECT * FROM tasks WHERE id=?", (cur.lastrowid,)).fetchone())), 201


@app.put("/api/tasks/<int:tid>")
def update_task(tid):
    d = body()
    db = get_db()
    row = db.execute("SELECT * FROM tasks WHERE id=?", (tid,)).fetchone()
    if not row:
        return bad("That task no longer exists.", 404)
    t = task_dict(row)
    if "title" in d:
        title = (d["title"] or "").strip()
        if not title:
            return bad("A task needs some words.")
        t["title"] = title[:500]
    if "notes" in d:
        t["notes"] = d["notes"] or ""
    if "today" in d:
        t["today"] = bool(d["today"])
    if "due" in d:
        t["due"] = valid_date(d["due"])
    if "project_id" in d and not t["parent_id"]:
        t["project_id"] = d["project_id"] or None
        t["position"] = next_position(db, t["project_id"], None)
        db.execute("UPDATE tasks SET project_id=? WHERE parent_id=?", (t["project_id"], tid))
    if "done" in d and bool(d["done"]) != t["done"]:
        t["done"] = bool(d["done"])
        t["done_at"] = now() if t["done"] else None
        if t["done"]:
            t["today"] = False
            # Finishing a task finishes its steps too.
            db.execute("UPDATE tasks SET done=1, done_at=COALESCE(done_at, ?), today=0 WHERE parent_id=? AND done=0",
                       (t["done_at"], tid))
    db.execute(
        "UPDATE tasks SET title=?, notes=?, today=?, due=?, project_id=?, done=?, done_at=?, position=? WHERE id=?",
        (t["title"], t["notes"], 1 if t["today"] else 0, t["due"], t["project_id"], 1 if t["done"] else 0,
         t["done_at"], t["position"], tid))
    db.commit()
    return jsonify(task_dict(db.execute("SELECT * FROM tasks WHERE id=?", (tid,)).fetchone()))


@app.delete("/api/tasks/<int:tid>")
def delete_task(tid):
    db = get_db()
    stamp = now()
    db.execute("UPDATE tasks SET deleted_at=? WHERE id=? OR parent_id=?", (stamp, tid, tid))
    db.commit()
    return jsonify({"ok": True, "deleted_at": stamp})


@app.post("/api/tasks/<int:tid>/restore")
def restore_task(tid):
    db = get_db()
    row = db.execute("SELECT deleted_at FROM tasks WHERE id=?", (tid,)).fetchone()
    if row and row["deleted_at"]:
        db.execute("UPDATE tasks SET deleted_at=NULL WHERE (id=? OR parent_id=?) AND deleted_at=?",
                   (tid, tid, row["deleted_at"]))
        db.commit()
    return jsonify({"ok": True})


@app.post("/api/tasks/reorder")
def reorder_tasks():
    ids = body().get("ids") or []
    db = get_db()
    for i, tid in enumerate(ids):
        db.execute("UPDATE tasks SET position=? WHERE id=?", (i + 1, tid))
    db.commit()
    return jsonify({"ok": True})


@app.post("/api/tasks/clear-today")
def clear_today():
    db = get_db()
    db.execute("UPDATE tasks SET today=0 WHERE today=1")
    db.commit()
    return jsonify({"ok": True})


# --------------------------------------------------------------------------- brain dump

BULLET = re.compile(r"^\s*(?:[-*•◦▪·+]|\d+[.)]|[a-z][.)])\s+", re.I)
CHECKED = re.compile(r"^\s*(?:\[[xX✓✔]\]|☑|✅|✔|✓)\s*")
UNCHECKED = re.compile(r"^\s*(?:\[\s?\]|☐|□|▢|⬜)\s*")


def parse_line(line):
    """Returns (title, done) for one list line, with bullets and checkboxes removed."""
    done = False
    s = line.strip()
    s = BULLET.sub("", s)
    if CHECKED.match(s):
        done, s = True, CHECKED.sub("", s)
    elif UNCHECKED.match(s):
        s = UNCHECKED.sub("", s)
    return s.strip(), done


def parse_dump(text):
    """Turns pasted text into tasks. Indented lines become steps of the line above."""
    items = []
    for raw in text.splitlines():
        if not raw.strip():
            continue
        expanded = raw.replace("\t", "    ")
        indent = len(expanded) - len(expanded.lstrip(" "))
        title, done = parse_line(raw)
        if not title:
            continue
        if indent >= 2 and items:
            items[-1]["steps"].append({"title": title, "done": done})
        else:
            items.append({"title": title, "done": done, "steps": []})
    return items


def insert_tasks(db, project_id, items, stamp="now"):
    """stamp is the done_at for items already ticked; None keeps imported ticks out of progress stats."""
    stamp = now() if stamp == "now" else stamp
    pos = next_position(db, project_id, None)
    count = 0
    for item in items:
        cur = db.execute(
            "INSERT INTO tasks (project_id, title, done, done_at, position) VALUES (?,?,?,?,?)",
            (project_id, item["title"][:500], 1 if item["done"] else 0, stamp if item["done"] else None, pos))
        pos += 1
        count += 1
        for j, step in enumerate(item.get("steps") or []):
            db.execute(
                "INSERT INTO tasks (project_id, parent_id, title, done, done_at, position) VALUES (?,?,?,?,?,?)",
                (project_id, cur.lastrowid, step["title"][:500], 1 if step["done"] else 0,
                 stamp if step["done"] else None, j + 1))
            count += 1
    return count


@app.post("/api/braindump")
def braindump():
    d = body()
    items = parse_dump(d.get("text") or "")
    if not items:
        return bad("Write or paste at least one line.")
    db = get_db()
    project_id = d.get("project_id") or None
    count = insert_tasks(db, project_id, items)
    db.commit()
    return jsonify({"added": count})


# --------------------------------------------------------------------------- Google Keep import

def keep_note_to_project(note, source_name):
    """Converts one Google Keep note (Takeout JSON) into a project preview."""
    title = (note.get("title") or "").strip()
    text = note.get("textContent") or ""
    tasks = []
    kind = "text"
    if note.get("listContent"):
        kind = "list"
        for item in note["listContent"]:
            t = (item.get("text") or "").strip()
            if t:
                tasks.append({"title": t, "done": bool(item.get("isChecked")), "steps": []})
    elif text.strip():
        lines = [ln for ln in text.splitlines() if ln.strip()]
        listy = [ln for ln in lines if BULLET.match(ln) or CHECKED.match(ln.strip()) or UNCHECKED.match(ln.strip())]
        if len(lines) >= 2 and len(listy) >= max(2, len(lines) // 2):
            kind = "text-list"
            tasks = parse_dump("\n".join(listy))
            rest = [ln for ln in lines if ln not in listy]
            if not title and rest:
                title, rest = rest[0].strip(), rest[1:]
            text = "\n".join(rest)
    if not title:
        first = (tasks[0]["title"] if tasks else text.strip().splitlines()[0] if text.strip() else "Untitled note")
        title = first[:60] + ("…" if len(first) > 60 else "")
    annotations = [a.get("url") for a in note.get("annotations") or [] if a.get("url")]
    if annotations:
        text = (text + "\n\nLinks:\n" + "\n".join(annotations)).strip()
    created = note.get("createdTimestampUsec") or note.get("userEditedTimestampUsec")
    created_iso = None
    if created:
        try:
            created_iso = dt.datetime.fromtimestamp(int(created) / 1_000_000).isoformat(timespec="seconds")
        except (ValueError, OSError):
            pass
    all_done = bool(tasks) and all(t["done"] for t in tasks)
    status = "archived" if note.get("isArchived") else "done" if all_done else "active"
    return {
        "key": f'keep:{note.get("createdTimestampUsec") or ""}:{title}',
        "source": source_name,
        "title": title,
        "notes": text.strip() if kind != "list" else "",
        "color": KEEP_COLORS.get(note.get("color") or "DEFAULT", "slate"),
        "labels": [l.get("name") for l in note.get("labels") or [] if l.get("name")],
        "pinned": bool(note.get("isPinned")),
        "archived": bool(note.get("isArchived")),
        "status": status,
        "kind": kind,
        "tasks": tasks,
        "created_at": created_iso,
        "edited": note.get("userEditedTimestampUsec") or 0,
    }


def looks_like_keep(obj):
    return isinstance(obj, dict) and ("textContent" in obj or "listContent" in obj) and "isTrashed" in obj


@app.post("/api/import/keep/preview")
def keep_preview():
    files = request.files.getlist("files")
    if not files:
        return bad("Choose your Google Takeout .zip file, or the .json files from its Keep folder.")
    notes, skipped_trash = [], 0

    def take(raw, name):
        nonlocal skipped_trash
        try:
            obj = json.loads(raw.decode("utf-8", errors="replace"))
        except json.JSONDecodeError:
            return
        if not looks_like_keep(obj):
            return
        if obj.get("isTrashed"):
            skipped_trash += 1
            return
        if not (obj.get("title") or obj.get("textContent") or obj.get("listContent")):
            return
        notes.append(keep_note_to_project(obj, name))

    for f in files:
        name = f.filename or ""
        data = f.read()
        if name.lower().endswith(".zip") or data[:2] == b"PK":
            try:
                zf = zipfile.ZipFile(io.BytesIO(data))
            except zipfile.BadZipFile:
                return bad(f"{name} isn’t a valid zip file.")
            for info in zf.infolist():
                if info.filename.lower().endswith(".json") and info.file_size < 5_000_000:
                    take(zf.read(info), info.filename.rsplit("/", 1)[-1])
        elif name.lower().endswith(".json"):
            take(data, name)

    if not notes:
        return bad("No Google Keep notes found. Make sure the Takeout export includes Keep, then choose the "
                   ".zip file (or the .json files inside its Keep folder).", 422)
    db = get_db()
    existing = {r["source_key"] for r in db.execute("SELECT source_key FROM projects WHERE source_key IS NOT NULL")}
    for n in notes:
        n["already_imported"] = n["key"] in existing
    notes.sort(key=lambda n: (not n["pinned"], n["archived"], -int(n["edited"] or 0)))
    return jsonify({"notes": notes, "skipped_trash": skipped_trash})


@app.post("/api/import/keep/commit")
def keep_commit():
    d = body()
    notes = d.get("notes") or []
    db = get_db()
    existing = {r["source_key"] for r in db.execute("SELECT source_key FROM projects WHERE source_key IS NOT NULL")}
    target_inbox = []
    projects = tasks = 0
    for n in notes:
        if n.get("key") in existing:
            continue
        if n.get("as_inbox"):
            target_inbox.extend(n.get("tasks") or [])  # noqa
            continue
        status = n.get("status") if n.get("status") in STATUSES else "active"
        cur = db.execute(
            "INSERT INTO projects (title, notes, color, status, pinned, labels, source_key, created_at, completed_at) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            ((n.get("title") or "Untitled note")[:200], n.get("notes") or "",
             n.get("color") if n.get("color") in COLORS else "slate", status, 1 if n.get("pinned") else 0,
             json.dumps(clean_labels(n.get("labels"))), n.get("key"), n.get("created_at") or now(),
             now() if status == "done" else None))
        projects += 1
        tasks += insert_tasks(db, cur.lastrowid, n.get("tasks") or [], stamp=None)
    if target_inbox:
        tasks += insert_tasks(db, None, target_inbox, stamp=None)
    db.commit()
    return jsonify({"projects": projects, "tasks": tasks})


# --------------------------------------------------------------------------- backup

@app.get("/api/export")
def export_all():
    db = get_db()
    out = []
    for p in db.execute("SELECT * FROM projects WHERE deleted_at IS NULL ORDER BY id"):
        pd = project_dict(p)
        pd["tasks"] = export_tasks(db, p["id"])
        out.append(pd)
    resp = jsonify({"app": "steady", "version": 1, "exported_at": now(),
                    "projects": out, "inbox": export_tasks(db, None)})
    resp.headers["Content-Disposition"] = f'attachment; filename="steady-backup-{dt.date.today()}.json"'
    return resp


def export_tasks(db, project_id):
    rows = [task_dict(r) for r in db.execute(
        "SELECT * FROM tasks WHERE project_id IS ? AND deleted_at IS NULL ORDER BY position, id", (project_id,))]
    tops = [r for r in rows if not r["parent_id"]]
    out = []
    for t in tops:
        steps = [{"title": s["title"], "done": s["done"], "done_at": s["done_at"]} for s in rows if s["parent_id"] == t["id"]]
        out.append({k: t[k] for k in ("title", "notes", "done", "done_at", "today", "due", "created_at")} | {"steps": steps})
    return out


@app.post("/api/import/backup")
def import_backup():
    d = body()
    if not isinstance(d, dict) or d.get("app") != "steady":
        return bad("That isn’t a Steady backup file.")
    db = get_db()

    def add_tasks(project_id, items):
        n = 0
        for i, t in enumerate(items or []):
            cur = db.execute(
                "INSERT INTO tasks (project_id, title, notes, done, done_at, today, due, position, created_at) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (project_id, t.get("title") or "Untitled", t.get("notes") or "", 1 if t.get("done") else 0,
                 t.get("done_at"), 1 if t.get("today") else 0, valid_date(t.get("due")), i + 1,
                 t.get("created_at") or now()))
            n += 1
            for j, s in enumerate(t.get("steps") or []):
                db.execute(
                    "INSERT INTO tasks (project_id, parent_id, title, done, done_at, position) VALUES (?,?,?,?,?,?)",
                    (project_id, cur.lastrowid, s.get("title") or "Untitled", 1 if s.get("done") else 0,
                     s.get("done_at"), j + 1))
                n += 1
        return n

    projects = tasks = 0
    for p in d.get("projects") or []:
        cur = db.execute(
            "INSERT INTO projects (title, notes, color, status, pinned, labels, source_key, created_at, completed_at) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (p.get("title") or "Untitled", p.get("notes") or "", p.get("color") if p.get("color") in COLORS else "slate",
             p.get("status") if p.get("status") in STATUSES else "active", 1 if p.get("pinned") else 0,
             json.dumps(clean_labels(p.get("labels"))), p.get("source_key"), p.get("created_at") or now(),
             p.get("completed_at")))
        projects += 1
        tasks += add_tasks(cur.lastrowid, p.get("tasks"))
    tasks += add_tasks(None, d.get("inbox"))
    db.commit()
    return jsonify({"projects": projects, "tasks": tasks})


# --------------------------------------------------------------------------- progress

@app.get("/api/stats")
def stats():
    db = get_db()
    today = dt.date.today()
    start = today - dt.timedelta(days=27)
    rows = db.execute(
        "SELECT substr(t.done_at, 1, 10) AS day, COUNT(*) AS n FROM tasks t "
        "LEFT JOIN projects p ON p.id = t.project_id "
        "WHERE t.done = 1 AND t.done_at >= ? AND t.deleted_at IS NULL AND (p.id IS NULL OR p.deleted_at IS NULL) "
        "GROUP BY day", (start.isoformat(),)).fetchall()
    counts = {r["day"]: r["n"] for r in rows}
    days = [{"day": (start + dt.timedelta(days=i)).isoformat(),
             "done": counts.get((start + dt.timedelta(days=i)).isoformat(), 0)} for i in range(28)]
    week_start = today - dt.timedelta(days=today.weekday())
    this_week = sum(d["done"] for d in days if d["day"] >= week_start.isoformat())
    recent = [task_dict(r) | {"project_title": r["project_title"], "project_color": r["project_color"]} for r in db.execute(
        "SELECT t.*, p.title AS project_title, p.color AS project_color FROM tasks t "
        "LEFT JOIN projects p ON p.id = t.project_id "
        "WHERE t.done = 1 AND t.done_at IS NOT NULL AND t.deleted_at IS NULL AND (p.id IS NULL OR p.deleted_at IS NULL) "
        "ORDER BY t.done_at DESC LIMIT 20")]
    finished = [project_dict(r) for r in db.execute(
        "SELECT * FROM projects WHERE status='done' AND deleted_at IS NULL AND completed_at IS NOT NULL "
        "ORDER BY completed_at DESC LIMIT 10")]
    return jsonify({"days": days, "this_week": this_week, "recent": recent, "finished_projects": finished})


# --------------------------------------------------------------------------- pages

@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/healthz")
def health():
    return "ok"


init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8081)), debug=False)
